DROP POLICY IF EXISTS "vehicles write" ON public.vehicles;
DROP POLICY IF EXISTS "vehicles read" ON public.vehicles;

CREATE POLICY "Authenticated users can view vehicles" ON public.vehicles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can insert vehicles" ON public.vehicles
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Authenticated users can update vehicles" ON public.vehicles
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Managers can delete vehicles" ON public.vehicles
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'manager'));