import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { currency, dateFmt, downloadCSV, number } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({ meta: [{ title: "Reports — TransitOps" }] }),
  component: ReportsPage,
});

function ReportsPage() {
  const { data } = useQuery({
    queryKey: ["reports"],
    queryFn: async () => {
      const [v, d, t, m, f, e] = await Promise.all([
        supabase.from("vehicles").select("*"),
        supabase.from("drivers").select("*"),
        supabase.from("trips").select("*"),
        supabase.from("maintenance_records").select("*"),
        supabase.from("fuel_logs").select("*"),
        supabase.from("expenses").select("*"),
      ]);
      return { vehicles: v.data ?? [], drivers: d.data ?? [], trips: t.data ?? [], maint: m.data ?? [], fuel: f.data ?? [], expenses: e.data ?? [] };
    },
  });

  if (!data) return <><PageHeader title="Reports" /><div className="h-40 animate-pulse rounded-lg bg-muted" /></>;

  const active = data.vehicles.filter((v) => v.status !== "retired").length;
  const util = active ? Math.round((data.vehicles.filter((v) => v.status === "on_trip").length / active) * 100) : 0;
  const totalFuel = data.fuel.reduce((s, f) => s + Number(f.cost), 0);
  const totalLiters = data.fuel.reduce((s, f) => s + Number(f.quantity_liters), 0);
  const totalDistance = data.trips.reduce((s, t) => s + Number(t.distance_km), 0);
  const efficiency = totalLiters ? (totalDistance / totalLiters).toFixed(2) : "0";
  const totalMaint = data.maint.reduce((s, m) => s + Number(m.cost), 0);
  const totalExpenses = data.expenses.reduce((s, e) => s + Number(e.amount), 0) + totalFuel + totalMaint;

  const vehiclePerf = data.vehicles.map((v) => {
    const trips = data.trips.filter((t) => t.vehicle_id === v.id);
    const dist = trips.reduce((s, t) => s + Number(t.distance_km), 0);
    const fuelCost = data.fuel.filter((f) => f.vehicle_id === v.id).reduce((s, f) => s + Number(f.cost), 0);
    const maintCost = data.maint.filter((m) => m.vehicle_id === v.id).reduce((s, m) => s + Number(m.cost), 0);
    return { registration: v.registration_number, name: v.name, trips: trips.length, distance_km: dist, fuel_cost: fuelCost, maintenance_cost: maintCost };
  });

  const driverPerf = data.drivers.map((d) => {
    const trips = data.trips.filter((t) => t.driver_id === d.id);
    return { name: d.full_name, license: d.license_number, safety_score: d.safety_score, trips: trips.length, distance_km: trips.reduce((s, t) => s + Number(t.distance_km), 0) };
  });

  const reports: { title: string; desc: string; stat: string; rows: () => Record<string, unknown>[] }[] = [
    { title: "Fleet utilization", desc: "Active vehicles vs. on trip", stat: `${util}%`, rows: () => data.vehicles.map((v) => ({ registration: v.registration_number, name: v.name, status: v.status })) },
    { title: "Fuel efficiency", desc: "Overall km per liter", stat: `${efficiency} km/L`, rows: () => data.fuel.map((f) => ({ date: f.fuel_date, vehicle_id: f.vehicle_id, liters: f.quantity_liters, cost: f.cost, station: f.station })) },
    { title: "Maintenance costs", desc: "Total maintenance spend", stat: currency(totalMaint), rows: () => data.maint.map((m) => ({ vehicle_id: m.vehicle_id, type: m.maintenance_type, date: m.scheduled_date, status: m.status, cost: m.cost })) },
    { title: "Trip history", desc: `${data.trips.length} trips recorded`, stat: `${number(totalDistance)} km`, rows: () => data.trips.map((t) => ({ source: t.source, destination: t.destination, distance_km: t.distance_km, cargo_kg: t.cargo_weight_kg, departure: t.departure_date, arrival: t.arrival_date, status: t.status })) },
    { title: "Driver performance", desc: "Trips and safety scores", stat: `${driverPerf.length} drivers`, rows: () => driverPerf },
    { title: "Vehicle performance", desc: "Trips, distance, cost per vehicle", stat: `${vehiclePerf.length} vehicles`, rows: () => vehiclePerf },
    { title: "Expense analysis", desc: "All operational spend", stat: currency(totalExpenses), rows: () => data.expenses.map((e) => ({ date: e.expense_date, type: e.expense_type, amount: e.amount, description: e.description })) },
  ];

  return (
    <>
      <PageHeader title="Reports" description="Export operational insights to CSV." />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {reports.map((r) => (
          <Card key={r.title}>
            <CardHeader><CardTitle>{r.title}</CardTitle><CardDescription>{r.desc}</CardDescription></CardHeader>
            <CardContent>
              <p className="mb-4 text-3xl font-bold tracking-tight text-primary">{r.stat}</p>
              <Button variant="outline" onClick={() => downloadCSV(`${r.title.toLowerCase().replace(/\s+/g,"_")}_${dateFmt(new Date())}.csv`, r.rows())}>
                <Download className="mr-2 h-4 w-4" />Export CSV
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  );
}
