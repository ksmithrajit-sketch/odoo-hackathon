import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, StatusBadge, DialogClose, type Column } from "@/components/crud-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { number, dateFmt } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/vehicles")({
  head: () => ({ meta: [{ title: "Vehicles — TransitOps" }] }),
  component: VehiclesPage,
});

type Vehicle = {
  id: string; registration_number: string; name: string; vehicle_type: string;
  capacity_kg: number; odometer_km: number; purchase_date: string | null;
  status: "available" | "on_trip" | "in_shop" | "retired"; notes: string | null;
};

function VehicleForm({ initial, onDone }: { initial?: Vehicle; onDone: () => void }) {
  const [saving, setSaving] = useState(false);
  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      registration_number: String(fd.get("registration_number")).trim().toUpperCase(),
      name: String(fd.get("name")),
      vehicle_type: String(fd.get("vehicle_type")),
      capacity_kg: Number(fd.get("capacity_kg") || 0),
      odometer_km: Number(fd.get("odometer_km") || 0),
      purchase_date: (fd.get("purchase_date") || null) as string | null,
      status: String(fd.get("status")) as Vehicle["status"],
      notes: (fd.get("notes") || null) as string | null,
    };
    setSaving(true);
    const { error } = initial
      ? await supabase.from("vehicles").update(payload).eq("id", initial.id)
      : await supabase.from("vehicles").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Vehicle updated" : "Vehicle added");
    onDone();
  };
  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><Label>Registration #</Label><Input name="registration_number" required defaultValue={initial?.registration_number} /></div>
        <div><Label>Vehicle name</Label><Input name="name" required defaultValue={initial?.name} /></div>
        <div><Label>Type</Label>
          <Select name="vehicle_type" defaultValue={initial?.vehicle_type ?? "Truck"}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["Truck","Van","Trailer","Container","Refrigerated","Tanker","Pickup"].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Status</Label>
          <Select name="status" defaultValue={initial?.status ?? "available"}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["available","on_trip","in_shop","retired"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Capacity (kg)</Label><Input name="capacity_kg" type="number" min="0" defaultValue={initial?.capacity_kg ?? 0} /></div>
        <div><Label>Odometer (km)</Label><Input name="odometer_km" type="number" min="0" defaultValue={initial?.odometer_km ?? 0} /></div>
        <div className="sm:col-span-2"><Label>Purchase date</Label><Input name="purchase_date" type="date" defaultValue={initial?.purchase_date ?? ""} /></div>
        <div className="sm:col-span-2"><Label>Notes</Label><Input name="notes" defaultValue={initial?.notes ?? ""} /></div>
      </div>
      <DialogClose onClose={onDone} label="Cancel" />
      {saving && <p className="text-xs text-muted-foreground">Saving…</p>}
    </form>
  );
}

function VehiclesPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const columns: Column<Vehicle>[] = [
    { key: "registration_number", label: "Reg #", sortable: true, render: (r) => <span className="font-mono font-semibold">{r.registration_number}</span> },
    { key: "name", label: "Name", sortable: true },
    { key: "vehicle_type", label: "Type" },
    { key: "capacity_kg", label: "Capacity", render: (r) => `${number(r.capacity_kg)} kg` },
    { key: "odometer_km", label: "Odometer", render: (r) => `${number(r.odometer_km)} km` },
    { key: "purchase_date", label: "Purchased", render: (r) => dateFmt(r.purchase_date) },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];
  return (
    <>
      <PageHeader title="Vehicles" description="Manage your fleet inventory, capacity, and availability." />
      <CrudTable<Vehicle>
        table="vehicles"
        columns={columns}
        searchKeys={["registration_number","name","vehicle_type"]}
        orderBy={{ column: "created_at" }}
        csvName="vehicles"
        filterFn={(r) => statusFilter === "all" || r.status === statusFilter}
        filterBar={
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {["available","on_trip","in_shop","retired"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}
            </SelectContent>
          </Select>
        }
        createForm={(done) => <VehicleForm onDone={done} />}
        editForm={(row, done) => <VehicleForm initial={row} onDone={done} />}
      />
    </>
  );
}
