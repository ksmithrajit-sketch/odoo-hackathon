import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, StatusBadge, DialogClose, type Column } from "@/components/crud-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { currency, dateFmt } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/maintenance")({
  head: () => ({ meta: [{ title: "Maintenance — TransitOps" }] }),
  component: MaintenancePage,
});

type Rec = {
  id: string; vehicle_id: string; maintenance_type: string; description: string | null;
  scheduled_date: string; cost: number; status: "pending" | "completed";
};

function useVehicles() {
  return useQuery({ queryKey: ["vehicles"], queryFn: async () => (await supabase.from("vehicles").select("*")).data ?? [] });
}

function MaintForm({ initial, onDone }: { initial?: Rec; onDone: () => void }) {
  const { data: vehicles = [] } = useVehicles();
  const [vehicleId, setVehicleId] = useState(initial?.vehicle_id ?? "");
  const [status, setStatus] = useState<Rec["status"]>(initial?.status ?? "pending");
  const [type, setType] = useState(initial?.maintenance_type ?? "Service");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!vehicleId) return toast.error("Pick a vehicle");
    const fd = new FormData(e.currentTarget);
    const payload = {
      vehicle_id: vehicleId,
      maintenance_type: type,
      description: (fd.get("description") || null) as string | null,
      scheduled_date: String(fd.get("scheduled_date")),
      cost: Number(fd.get("cost") || 0),
      status,
    };
    const { error } = initial
      ? await supabase.from("maintenance_records").update(payload).eq("id", initial.id)
      : await supabase.from("maintenance_records").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Record updated" : "Record added");
    onDone();
  };
  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><Label>Vehicle</Label>
          <Select value={vehicleId} onValueChange={setVehicleId}>
            <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
            <SelectContent>{vehicles.map((v: any) => <SelectItem key={v.id} value={v.id}>{v.registration_number} — {v.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Type</Label>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["Service","Oil change","Tire","Brakes","Engine","Inspection","Repair"].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Scheduled date</Label><Input name="scheduled_date" type="date" required defaultValue={initial?.scheduled_date ?? new Date().toISOString().slice(0,10)} /></div>
        <div><Label>Cost</Label><Input name="cost" type="number" step="0.01" min="0" defaultValue={initial?.cost ?? 0} /></div>
        <div><Label>Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as Rec["status"])}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["pending","completed"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2"><Label>Description</Label><Input name="description" defaultValue={initial?.description ?? ""} /></div>
      </div>
      <DialogClose onClose={onDone} />
    </form>
  );
}

function MaintenancePage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { data: vehicles = [] } = useVehicles();
  const vmap = new Map(vehicles.map((v: any) => [v.id, v]));

  const columns: Column<Rec>[] = [
    { key: "vehicle_id", label: "Vehicle", render: (r) => (vmap.get(r.vehicle_id) as any)?.registration_number ?? "—" },
    { key: "maintenance_type", label: "Type" },
    { key: "description", label: "Description", render: (r) => r.description ?? "—" },
    { key: "scheduled_date", label: "Date", sortable: true, render: (r) => dateFmt(r.scheduled_date) },
    { key: "cost", label: "Cost", render: (r) => currency(r.cost) },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];
  return (
    <>
      <PageHeader title="Maintenance" description="Vehicles under maintenance are automatically marked In Shop." />
      <CrudTable<Rec>
        table="maintenance_records"
        columns={columns}
        searchKeys={["maintenance_type","description"]}
        orderBy={{ column: "scheduled_date" }}
        csvName="maintenance"
        filterFn={(r) => statusFilter === "all" || r.status === statusFilter}
        filterBar={
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {["pending","completed"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
            </SelectContent>
          </Select>
        }
        createForm={(done) => <MaintForm onDone={done} />}
        editForm={(row, done) => <MaintForm initial={row} onDone={done} />}
      />
    </>
  );
}
