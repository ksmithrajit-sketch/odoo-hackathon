import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, StatusBadge, DialogClose, type Column } from "@/components/crud-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { number, dateTimeFmt } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/trips")({
  head: () => ({ meta: [{ title: "Trips — TransitOps" }] }),
  component: TripsPage,
});

type Trip = {
  id: string; source: string; destination: string; vehicle_id: string | null; driver_id: string | null;
  cargo_weight_kg: number; distance_km: number; departure_date: string; arrival_date: string | null;
  status: "scheduled" | "in_progress" | "completed" | "cancelled"; notes: string | null;
};

function useRefs() {
  const vehicles = useQuery({ queryKey: ["vehicles"], queryFn: async () => (await supabase.from("vehicles").select("*")).data ?? [] });
  const drivers = useQuery({ queryKey: ["drivers"], queryFn: async () => (await supabase.from("drivers").select("*")).data ?? [] });
  return { vehicles: vehicles.data ?? [], drivers: drivers.data ?? [] };
}

function TripForm({ initial, onDone }: { initial?: Trip; onDone: () => void }) {
  const { vehicles, drivers } = useRefs();
  const [vehicleId, setVehicleId] = useState<string>(initial?.vehicle_id ?? "");
  const [driverId, setDriverId] = useState<string>(initial?.driver_id ?? "");
  const [status, setStatus] = useState<Trip["status"]>(initial?.status ?? "scheduled");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const cargo = Number(fd.get("cargo_weight_kg") || 0);
    const veh = vehicles.find((v) => v.id === vehicleId);
    const drv = drivers.find((d) => d.id === driverId);
    if (!veh) return toast.error("Select a vehicle");
    if (!drv) return toast.error("Select a driver");
    if (cargo > Number(veh.capacity_kg)) return toast.error(`Cargo (${cargo}kg) exceeds vehicle capacity (${veh.capacity_kg}kg)`);
    if (new Date(drv.license_expiry) < new Date()) return toast.error("Driver license is expired");
    if (status === "in_progress") {
      if (!initial || initial.vehicle_id !== vehicleId) {
        if (veh.status === "on_trip" || veh.status === "in_shop") return toast.error(`Vehicle is ${veh.status.replace("_"," ")}`);
      }
      if (!initial || initial.driver_id !== driverId) {
        if (drv.status === "on_trip" || drv.status === "inactive") return toast.error(`Driver is ${drv.status.replace("_"," ")}`);
      }
    }
    const payload = {
      source: String(fd.get("source")),
      destination: String(fd.get("destination")),
      vehicle_id: vehicleId, driver_id: driverId,
      cargo_weight_kg: cargo,
      distance_km: Number(fd.get("distance_km") || 0),
      departure_date: new Date(String(fd.get("departure_date"))).toISOString(),
      arrival_date: fd.get("arrival_date") ? new Date(String(fd.get("arrival_date"))).toISOString() : null,
      status,
      notes: (fd.get("notes") || null) as string | null,
    };
    const { error } = initial
      ? await supabase.from("trips").update(payload).eq("id", initial.id)
      : await supabase.from("trips").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Trip updated" : "Trip created");
    onDone();
  };

  const toLocalInput = (iso?: string | null) => iso ? new Date(iso).toISOString().slice(0, 16) : "";

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><Label>Source</Label><Input name="source" required defaultValue={initial?.source} /></div>
        <div><Label>Destination</Label><Input name="destination" required defaultValue={initial?.destination} /></div>
        <div><Label>Vehicle</Label>
          <Select value={vehicleId} onValueChange={setVehicleId}>
            <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
            <SelectContent>{vehicles.map((v: any) => <SelectItem key={v.id} value={v.id}>{v.registration_number} — {v.name} ({v.status})</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Driver</Label>
          <Select value={driverId} onValueChange={setDriverId}>
            <SelectTrigger><SelectValue placeholder="Select driver" /></SelectTrigger>
            <SelectContent>{drivers.map((d: any) => <SelectItem key={d.id} value={d.id}>{d.full_name} ({d.status})</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Cargo (kg)</Label><Input name="cargo_weight_kg" type="number" min="0" defaultValue={initial?.cargo_weight_kg ?? 0} /></div>
        <div><Label>Distance (km)</Label><Input name="distance_km" type="number" min="0" defaultValue={initial?.distance_km ?? 0} /></div>
        <div><Label>Departure</Label><Input name="departure_date" type="datetime-local" required defaultValue={toLocalInput(initial?.departure_date)} /></div>
        <div><Label>Arrival</Label><Input name="arrival_date" type="datetime-local" defaultValue={toLocalInput(initial?.arrival_date)} /></div>
        <div className="sm:col-span-2"><Label>Status</Label>
          <Select value={status} onValueChange={(v) => setStatus(v as Trip["status"])}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["scheduled","in_progress","completed","cancelled"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2"><Label>Notes</Label><Input name="notes" defaultValue={initial?.notes ?? ""} /></div>
      </div>
      <DialogClose onClose={onDone} />
    </form>
  );
}

function TripsPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { vehicles, drivers } = useRefs();
  const vmap = new Map(vehicles.map((v: any) => [v.id, v]));
  const dmap = new Map(drivers.map((d: any) => [d.id, d]));

  const columns: Column<Trip>[] = [
    { key: "source", label: "Route", render: (r) => <span className="font-medium">{r.source} → {r.destination}</span> },
    { key: "vehicle_id", label: "Vehicle", render: (r) => (vmap.get(r.vehicle_id ?? "") as any)?.registration_number ?? "—" },
    { key: "driver_id", label: "Driver", render: (r) => (dmap.get(r.driver_id ?? "") as any)?.full_name ?? "—" },
    { key: "distance_km", label: "Distance", render: (r) => `${number(r.distance_km)} km` },
    { key: "cargo_weight_kg", label: "Cargo", render: (r) => `${number(r.cargo_weight_kg)} kg` },
    { key: "departure_date", label: "Departure", sortable: true, render: (r) => dateTimeFmt(r.departure_date) },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];
  return (
    <>
      <PageHeader title="Trips" description="Schedule and dispatch trips. Business rules on capacity and license enforced." />
      <CrudTable<Trip>
        table="trips"
        columns={columns}
        searchKeys={["source","destination","notes"]}
        orderBy={{ column: "departure_date" }}
        csvName="trips"
        filterFn={(r) => statusFilter === "all" || r.status === statusFilter}
        filterBar={
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {["scheduled","in_progress","completed","cancelled"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}
            </SelectContent>
          </Select>
        }
        createForm={(done) => <TripForm onDone={done} />}
        editForm={(row, done) => <TripForm initial={row} onDone={done} />}
      />
    </>
  );
}
