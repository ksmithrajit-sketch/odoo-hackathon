import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, DialogClose, type Column } from "@/components/crud-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { currency, dateFmt, number } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/fuel")({
  head: () => ({ meta: [{ title: "Fuel — TransitOps" }] }),
  component: FuelPage,
});

type Fuel = {
  id: string; vehicle_id: string; trip_id: string | null;
  quantity_liters: number; cost: number; station: string | null; fuel_date: string;
};

function useRefs() {
  const v = useQuery({ queryKey: ["vehicles"], queryFn: async () => (await supabase.from("vehicles").select("*")).data ?? [] });
  const t = useQuery({ queryKey: ["trips"], queryFn: async () => (await supabase.from("trips").select("*").order("departure_date", { ascending: false }).limit(200)).data ?? [] });
  return { vehicles: v.data ?? [], trips: t.data ?? [] };
}

function FuelForm({ initial, onDone }: { initial?: Fuel; onDone: () => void }) {
  const { vehicles, trips } = useRefs();
  const [vehicleId, setVehicleId] = useState(initial?.vehicle_id ?? "");
  const [tripId, setTripId] = useState(initial?.trip_id ?? "none");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!vehicleId) return toast.error("Pick a vehicle");
    const fd = new FormData(e.currentTarget);
    const payload = {
      vehicle_id: vehicleId,
      trip_id: tripId === "none" ? null : tripId,
      quantity_liters: Number(fd.get("quantity_liters") || 0),
      cost: Number(fd.get("cost") || 0),
      station: (fd.get("station") || null) as string | null,
      fuel_date: String(fd.get("fuel_date")),
    };
    const { error } = initial
      ? await supabase.from("fuel_logs").update(payload).eq("id", initial.id)
      : await supabase.from("fuel_logs").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Fuel updated" : "Fuel logged");
    onDone();
  };
  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><Label>Vehicle</Label>
          <Select value={vehicleId} onValueChange={setVehicleId}>
            <SelectTrigger><SelectValue placeholder="Select vehicle" /></SelectTrigger>
            <SelectContent>{vehicles.map((v: any) => <SelectItem key={v.id} value={v.id}>{v.registration_number}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Trip (optional)</Label>
          <Select value={tripId} onValueChange={setTripId}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              {trips.map((t: any) => <SelectItem key={t.id} value={t.id}>{t.source} → {t.destination}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Quantity (liters)</Label><Input name="quantity_liters" type="number" step="0.01" min="0" required defaultValue={initial?.quantity_liters ?? ""} /></div>
        <div><Label>Cost</Label><Input name="cost" type="number" step="0.01" min="0" required defaultValue={initial?.cost ?? ""} /></div>
        <div><Label>Station</Label><Input name="station" defaultValue={initial?.station ?? ""} /></div>
        <div><Label>Date</Label><Input name="fuel_date" type="date" required defaultValue={initial?.fuel_date ?? new Date().toISOString().slice(0,10)} /></div>
      </div>
      <DialogClose onClose={onDone} />
    </form>
  );
}

function FuelPage() {
  const { vehicles } = useRefs();
  const vmap = new Map(vehicles.map((v: any) => [v.id, v]));
  const columns: Column<Fuel>[] = [
    { key: "vehicle_id", label: "Vehicle", render: (r) => (vmap.get(r.vehicle_id) as any)?.registration_number ?? "—" },
    { key: "quantity_liters", label: "Liters", render: (r) => `${number(r.quantity_liters)} L` },
    { key: "cost", label: "Cost", render: (r) => currency(r.cost) },
    { key: "station", label: "Station", render: (r) => r.station ?? "—" },
    { key: "fuel_date", label: "Date", sortable: true, render: (r) => dateFmt(r.fuel_date) },
  ];
  return (
    <>
      <PageHeader title="Fuel" description="Track fuel purchases per vehicle and trip." />
      <CrudTable<Fuel>
        table="fuel_logs"
        columns={columns}
        searchKeys={["station"]}
        orderBy={{ column: "fuel_date" }}
        csvName="fuel"
        createForm={(done) => <FuelForm onDone={done} />}
        editForm={(row, done) => <FuelForm initial={row} onDone={done} />}
      />
    </>
  );
}
