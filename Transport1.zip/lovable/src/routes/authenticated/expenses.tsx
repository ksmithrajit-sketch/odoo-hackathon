import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, DialogClose, type Column } from "@/components/crud-table";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { currency, dateFmt } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/expenses")({
  head: () => ({ meta: [{ title: "Expenses — TransitOps" }] }),
  component: ExpensesPage,
});

type Expense = {
  id: string; vehicle_id: string | null; expense_type: "fuel"|"maintenance"|"insurance"|"toll"|"other";
  amount: number; description: string | null; expense_date: string;
};

function useVehicles() {
  return useQuery({ queryKey: ["vehicles"], queryFn: async () => (await supabase.from("vehicles").select("*")).data ?? [] });
}

function ExpenseForm({ initial, onDone }: { initial?: Expense; onDone: () => void }) {
  const { data: vehicles = [] } = useVehicles();
  const [vehicleId, setVehicleId] = useState(initial?.vehicle_id ?? "none");
  const [type, setType] = useState<Expense["expense_type"]>(initial?.expense_type ?? "other");

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      vehicle_id: vehicleId === "none" ? null : vehicleId,
      expense_type: type,
      amount: Number(fd.get("amount") || 0),
      description: (fd.get("description") || null) as string | null,
      expense_date: String(fd.get("expense_date")),
    };
    const { error } = initial
      ? await supabase.from("expenses").update(payload).eq("id", initial.id)
      : await supabase.from("expenses").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Expense updated" : "Expense added");
    onDone();
  };
  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><Label>Vehicle</Label>
          <Select value={vehicleId} onValueChange={setVehicleId}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              {vehicles.map((v: any) => <SelectItem key={v.id} value={v.id}>{v.registration_number}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Type</Label>
          <Select value={type} onValueChange={(v) => setType(v as any)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["fuel","maintenance","insurance","toll","other"].map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Amount</Label><Input name="amount" type="number" step="0.01" min="0" required defaultValue={initial?.amount ?? ""} /></div>
        <div><Label>Date</Label><Input name="expense_date" type="date" required defaultValue={initial?.expense_date ?? new Date().toISOString().slice(0,10)} /></div>
        <div className="sm:col-span-2"><Label>Description</Label><Input name="description" defaultValue={initial?.description ?? ""} /></div>
      </div>
      <DialogClose onClose={onDone} />
    </form>
  );
}

function ExpensesPage() {
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const { data: vehicles = [] } = useVehicles();
  const vmap = new Map(vehicles.map((v: any) => [v.id, v]));

  const { data: allExpenses = [] } = useQuery<Expense[]>({
    queryKey: ["expenses"],
    queryFn: async () => (await supabase.from("expenses").select("*")).data as Expense[] ?? [],
  });
  const total = allExpenses.reduce((s, e) => s + Number(e.amount), 0);
  const thisMonth = allExpenses
    .filter((e) => new Date(e.expense_date).getMonth() === new Date().getMonth() && new Date(e.expense_date).getFullYear() === new Date().getFullYear())
    .reduce((s, e) => s + Number(e.amount), 0);

  const columns: Column<Expense>[] = [
    { key: "expense_date", label: "Date", sortable: true, render: (r) => dateFmt(r.expense_date) },
    { key: "expense_type", label: "Type", render: (r) => <Badge variant="outline" className="capitalize">{r.expense_type}</Badge> },
    { key: "vehicle_id", label: "Vehicle", render: (r) => (vmap.get(r.vehicle_id ?? "") as any)?.registration_number ?? "—" },
    { key: "description", label: "Description", render: (r) => r.description ?? "—" },
    { key: "amount", label: "Amount", render: (r) => <span className="font-semibold">{currency(r.amount)}</span> },
  ];

  return (
    <>
      <PageHeader title="Expenses" description="Track and analyze operational spend." />
      <div className="mb-4 grid gap-4 sm:grid-cols-3">
        <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Total spend</p><p className="mt-2 text-2xl font-bold">{currency(total)}</p></CardContent></Card>
        <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">This month</p><p className="mt-2 text-2xl font-bold">{currency(thisMonth)}</p></CardContent></Card>
        <Card><CardContent className="p-5"><p className="text-xs uppercase text-muted-foreground">Entries</p><p className="mt-2 text-2xl font-bold">{allExpenses.length}</p></CardContent></Card>
      </div>
      <CrudTable<Expense>
        table="expenses"
        columns={columns}
        searchKeys={["description"]}
        orderBy={{ column: "expense_date" }}
        csvName="expenses"
        filterFn={(r) => typeFilter === "all" || r.expense_type === typeFilter}
        filterBar={
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="h-9 w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {["fuel","maintenance","insurance","toll","other"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}
            </SelectContent>
          </Select>
        }
        createForm={(done) => <ExpenseForm onDone={done} />}
        editForm={(row, done) => <ExpenseForm initial={row} onDone={done} />}
      />
    </>
  );
}
