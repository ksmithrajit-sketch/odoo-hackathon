import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profile — TransitOps" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const [profile, setProfile] = useState<{ id: string; full_name: string | null; email: string | null; phone: string | null } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return;
      const { data } = await supabase.from("profiles").select("*").eq("id", u.user.id).maybeSingle();
      setProfile(data ?? { id: u.user.id, full_name: null, email: u.user.email ?? null, phone: null });
      setLoading(false);
    })();
  }, []);

  const save = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!profile) return;
    const fd = new FormData(e.currentTarget);
    const payload = {
      id: profile.id,
      full_name: String(fd.get("full_name") ?? ""),
      email: profile.email,
      phone: String(fd.get("phone") ?? "") || null,
    };
    const { error } = await supabase.from("profiles").upsert(payload);
    if (error) return toast.error(error.message);
    toast.success("Profile saved");
  };

  const updatePassword = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const { error } = await supabase.auth.updateUser({ password: String(fd.get("password")) });
    if (error) return toast.error(error.message);
    toast.success("Password updated");
    (e.currentTarget as HTMLFormElement).reset();
  };

  if (loading || !profile) return <><PageHeader title="Profile" /><div className="h-40 animate-pulse rounded-lg bg-muted" /></>;

  const initials = (profile.full_name || profile.email || "U").split(/\s+/).map((s) => s[0]).slice(0, 2).join("").toUpperCase();

  return (
    <>
      <PageHeader title="Profile" description="Your personal account details." />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Details</CardTitle><CardDescription>Update your public info.</CardDescription></CardHeader>
          <CardContent>
            <form onSubmit={save} className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16"><AvatarFallback className="bg-primary text-primary-foreground text-lg">{initials}</AvatarFallback></Avatar>
                <div><p className="font-medium">{profile.full_name || "Unnamed"}</p><p className="text-sm text-muted-foreground">{profile.email}</p></div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div><Label>Full name</Label><Input name="full_name" defaultValue={profile.full_name ?? ""} required /></div>
                <div><Label>Email</Label><Input value={profile.email ?? ""} disabled /></div>
                <div className="sm:col-span-2"><Label>Phone</Label><Input name="phone" defaultValue={profile.phone ?? ""} /></div>
              </div>
              <Button type="submit">Save changes</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Password</CardTitle><CardDescription>Update your sign-in password.</CardDescription></CardHeader>
          <CardContent>
            <form onSubmit={updatePassword} className="space-y-3">
              <div><Label>New password</Label><Input name="password" type="password" minLength={6} required /></div>
              <Button type="submit" variant="secondary" className="w-full">Update password</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
