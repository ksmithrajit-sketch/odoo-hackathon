import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { useTheme } from "@/hooks/use-theme";
import { fetchUserRoles, type AppRole } from "@/hooks/use-session";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — TransitOps" }] }),
  component: SettingsPage,
});

const ROLES: AppRole[] = ["manager", "driver", "safety_officer", "finance"];

function SettingsPage() {
  const qc = useQueryClient();
  const { theme, setTheme } = useTheme();
  const [selfRoles, setSelfRoles] = useState<AppRole[]>([]);
  const [uid, setUid] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data }) => {
      if (!data.user) return;
      setUid(data.user.id);
      setSelfRoles(await fetchUserRoles(data.user.id));
    });
  }, []);

  const { data: members = [] } = useQuery({
    queryKey: ["team-members"],
    queryFn: async () => {
      const { data: profiles } = await supabase.from("profiles").select("*").order("created_at", { ascending: true });
      const { data: roles } = await supabase.from("user_roles").select("*");
      return (profiles ?? []).map((p: any) => ({
        ...p,
        roles: (roles ?? []).filter((r: any) => r.user_id === p.id).map((r: any) => r.role as AppRole),
      }));
    },
  });

  const isManager = selfRoles.includes("manager");

  const toggleRole = async (userId: string, role: AppRole, has: boolean) => {
    if (has) {
      await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", role);
    } else {
      await supabase.from("user_roles").insert({ user_id: userId, role });
    }
    toast.success("Roles updated");
    qc.invalidateQueries({ queryKey: ["team-members"] });
  };

  return (
    <>
      <PageHeader title="Settings" description="Preferences and team access." />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Appearance</CardTitle><CardDescription>Choose your theme.</CardDescription></CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-sm">Dark mode</span>
            <Switch checked={theme === "dark"} onCheckedChange={(v) => setTheme(v ? "dark" : "light")} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Your roles</CardTitle><CardDescription>What you can do in TransitOps.</CardDescription></CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {selfRoles.length === 0 ? <span className="text-sm text-muted-foreground">No roles yet.</span> :
              selfRoles.map((r) => <Badge key={r} className="capitalize">{r.replace("_"," ")}</Badge>)}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Team</CardTitle>
          <CardDescription>{isManager ? "Grant or revoke roles for team members." : "Only Managers can modify roles."}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground">
                <tr><th className="p-2 text-left">Member</th>{ROLES.map((r) => <th key={r} className="p-2 text-left capitalize">{r.replace("_"," ")}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-border">
                {members.map((m: any) => (
                  <tr key={m.id}>
                    <td className="p-2">
                      <div className="font-medium">{m.full_name || m.email}</div>
                      <div className="text-xs text-muted-foreground">{m.email}</div>
                    </td>
                    {ROLES.map((r) => {
                      const has = m.roles.includes(r);
                      return (
                        <td key={r} className="p-2">
                          {isManager && m.id !== uid ? (
                            <Switch checked={has} onCheckedChange={() => toggleRole(m.id, r, has)} />
                          ) : (
                            <Badge variant={has ? "default" : "outline"} className="capitalize">{has ? "Yes" : "—"}</Badge>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="mt-6">
        <Button variant="outline" onClick={async () => { await supabase.auth.signOut(); window.location.href = "/auth"; }}>Sign out</Button>
      </div>
    </>
  );
}
