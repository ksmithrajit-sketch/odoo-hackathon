import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Bell, Check, Trash2, AlertTriangle, Wrench, Truck, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { dateTimeFmt } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Notifications — TransitOps" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const qc = useQueryClient();

  // Auto-seed notifications from state
  useEffect(() => { void generateSystemNotifications(); }, []);

  const { data = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => (await supabase.from("notifications").select("*").order("created_at", { ascending: false })).data ?? [],
  });

  const markAllRead = async () => {
    const { error } = await supabase.from("notifications").update({ read: true }).eq("read", false);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };
  const del = async (id: string) => {
    await supabase.from("notifications").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };
  const mark = async (id: string) => {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };

  const iconFor = (kind: string) => {
    if (kind === "license_expired") return <AlertTriangle className="h-4 w-4 text-destructive" />;
    if (kind === "maintenance_pending") return <Wrench className="h-4 w-4 text-warning-foreground" />;
    if (kind === "vehicle_in_shop") return <Truck className="h-4 w-4 text-warning-foreground" />;
    if (kind === "trip_completed") return <CheckCircle2 className="h-4 w-4 text-success" />;
    return <Bell className="h-4 w-4 text-primary" />;
  };

  return (
    <>
      <PageHeader title="Notifications" description="License expirations, upcoming maintenance and trip milestones."
        actions={<Button variant="outline" onClick={markAllRead}><Check className="mr-2 h-4 w-4" />Mark all read</Button>} />
      <Card>
        <CardContent className="divide-y divide-border p-0">
          {data.length === 0 && <p className="p-8 text-center text-sm text-muted-foreground">You're all caught up.</p>}
          {data.map((n: any) => (
            <div key={n.id} className={cn("flex items-start gap-3 p-4", !n.read && "bg-primary/5")}>
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted">{iconFor(n.kind)}</div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="truncate font-medium">{n.title}</p>
                  {!n.read && <Badge variant="secondary">New</Badge>}
                </div>
                {n.message && <p className="mt-0.5 text-sm text-muted-foreground">{n.message}</p>}
                <p className="mt-1 text-xs text-muted-foreground">{dateTimeFmt(n.created_at)}</p>
              </div>
              <div className="flex gap-1">
                {!n.read && <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => mark(n.id)}><Check className="h-4 w-4" /></Button>}
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => del(n.id)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </>
  );
}

async function generateSystemNotifications() {
  try {
    const [{ data: drivers }, { data: vehicles }, { data: maint }, { data: trips }] = await Promise.all([
      supabase.from("drivers").select("*"),
      supabase.from("vehicles").select("*"),
      supabase.from("maintenance_records").select("*"),
      supabase.from("trips").select("*").order("updated_at", { ascending: false }).limit(20),
    ]);
    const { data: existing } = await supabase.from("notifications").select("title");
    const known = new Set((existing ?? []).map((n: any) => n.title));
    const inserts: any[] = [];
    const now = new Date();
    for (const d of drivers ?? []) {
      const exp = new Date(d.license_expiry);
      if (exp < now) {
        const title = `License expired: ${d.full_name}`;
        if (!known.has(title)) inserts.push({ title, message: `License ${d.license_number} expired ${exp.toDateString()}`, kind: "license_expired" });
      }
    }
    for (const m of maint ?? []) {
      if (m.status === "pending") {
        const veh = vehicles?.find((v: any) => v.id === m.vehicle_id);
        const title = `Maintenance pending: ${veh?.registration_number ?? "vehicle"}`;
        if (!known.has(title)) inserts.push({ title, message: `${m.maintenance_type} scheduled ${m.scheduled_date}`, kind: "maintenance_pending" });
      }
    }
    for (const v of vehicles ?? []) {
      if (v.status === "in_shop") {
        const title = `In shop: ${v.registration_number}`;
        if (!known.has(title)) inserts.push({ title, message: `Vehicle ${v.name} is under maintenance`, kind: "vehicle_in_shop" });
      }
    }
    for (const t of trips ?? []) {
      if (t.status === "completed") {
        const title = `Trip completed: ${t.source} → ${t.destination}`;
        if (!known.has(title)) inserts.push({ title, message: `Distance ${t.distance_km} km`, kind: "trip_completed" });
      }
    }
    if (inserts.length) await supabase.from("notifications").insert(inserts);
  } catch (e) { /* noop */ }
}
