import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Truck, Users, Route as RouteIcon, Wrench, DollarSign, Activity, Fuel, TrendingUp,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, PieChart, Pie, Cell, Legend, LineChart, Line,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { currency, dateFmt, monthKey, number } from "@/lib/format";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — TransitOps" }] }),
  component: Dashboard,
});

function Kpi({ label, value, hint, icon, tone = "default" }: { label: string; value: ReactNode; hint?: string; icon: ReactNode; tone?: "default" | "success" | "warning" | "info" | "accent" }) {
  const tones: Record<string, string> = {
    default: "bg-primary/10 text-primary",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning-foreground",
    info: "bg-info/15 text-info",
    accent: "bg-accent/15 text-accent-foreground",
  };
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
            <p className="mt-2 truncate text-2xl font-bold tracking-tight">{value}</p>
            {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
          </div>
          <div className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-lg", tones[tone])}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

const CHART_COLORS = ["var(--color-chart-1)", "var(--color-chart-2)", "var(--color-chart-3)", "var(--color-chart-4)", "var(--color-chart-5)"];

function Dashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-data"],
    queryFn: async () => {
      const [vehicles, drivers, trips, maint, fuel, expenses] = await Promise.all([
        supabase.from("vehicles").select("*"),
        supabase.from("drivers").select("*"),
        supabase.from("trips").select("*").order("departure_date", { ascending: false }).limit(500),
        supabase.from("maintenance_records").select("*"),
        supabase.from("fuel_logs").select("*"),
        supabase.from("expenses").select("*"),
      ]);
      return {
        vehicles: vehicles.data ?? [],
        drivers: drivers.data ?? [],
        trips: trips.data ?? [],
        maint: maint.data ?? [],
        fuel: fuel.data ?? [],
        expenses: expenses.data ?? [],
      };
    },
  });

  if (isLoading || !data) {
    return (
      <>
        <PageHeader title="Dashboard" description="Fleet overview loading…" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-28 animate-pulse rounded-lg bg-muted" />)}
        </div>
      </>
    );
  }

  const totalVehicles = data.vehicles.length;
  const availableVehicles = data.vehicles.filter((v) => v.status === "available").length;
  const activeVehicles = data.vehicles.filter((v) => v.status !== "retired").length;
  const inShop = data.vehicles.filter((v) => v.status === "in_shop").length;
  const totalDrivers = data.drivers.length;
  const driversOnTrip = data.drivers.filter((d) => d.status === "on_trip").length;
  const activeTrips = data.trips.filter((t) => t.status === "in_progress").length;
  const fleetUtil = activeVehicles > 0 ? Math.round((data.vehicles.filter((v) => v.status === "on_trip").length / activeVehicles) * 100) : 0;

  const thisMonth = new Date();
  const monthTag = monthKey(thisMonth);
  const monthlyExpenses = data.expenses.filter((e) => monthKey(e.expense_date) === monthTag).reduce((s, e) => s + Number(e.amount), 0)
    + data.fuel.filter((f) => monthKey(f.fuel_date) === monthTag).reduce((s, f) => s + Number(f.cost), 0)
    + data.maint.filter((m) => monthKey(m.scheduled_date) === monthTag && m.status === "completed").reduce((s, m) => s + Number(m.cost), 0);

  // trips per month (last 6)
  const months: string[] = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(monthKey(d));
  }
  const tripsByMonth = months.map((m) => ({
    month: new Date(m + "-01").toLocaleDateString("en-US", { month: "short" }),
    trips: data.trips.filter((t) => monthKey(t.departure_date) === m).length,
    completed: data.trips.filter((t) => monthKey(t.departure_date) === m && t.status === "completed").length,
  }));

  const fuelByMonth = months.map((m) => ({
    month: new Date(m + "-01").toLocaleDateString("en-US", { month: "short" }),
    cost: Math.round(data.fuel.filter((f) => monthKey(f.fuel_date) === m).reduce((s, f) => s + Number(f.cost), 0)),
    liters: Math.round(data.fuel.filter((f) => monthKey(f.fuel_date) === m).reduce((s, f) => s + Number(f.quantity_liters), 0)),
  }));

  const maintByMonth = months.map((m) => ({
    month: new Date(m + "-01").toLocaleDateString("en-US", { month: "short" }),
    cost: Math.round(data.maint.filter((r) => monthKey(r.scheduled_date) === m).reduce((s, r) => s + Number(r.cost), 0)),
  }));

  const expenseBreakdown = Object.entries(
    data.expenses.reduce<Record<string, number>>((acc, e) => {
      acc[e.expense_type] = (acc[e.expense_type] || 0) + Number(e.amount);
      return acc;
    }, {}),
  ).map(([name, value]) => ({ name, value }));

  const perf = data.vehicles.slice(0, 6).map((v) => {
    const vTrips = data.trips.filter((t) => t.vehicle_id === v.id);
    return {
      name: v.registration_number,
      trips: vTrips.length,
      distance: Math.round(vTrips.reduce((s, t) => s + Number(t.distance_km), 0)),
    };
  });

  const recentTrips = data.trips.slice(0, 6);

  return (
    <>
      <PageHeader title="Dashboard" description="Real-time overview of your fleet operations" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="Total vehicles" value={number(totalVehicles)} hint={`${activeVehicles} active`} icon={<Truck className="h-5 w-5" />} />
        <Kpi label="Available" value={number(availableVehicles)} hint="Ready to dispatch" icon={<Activity className="h-5 w-5" />} tone="success" />
        <Kpi label="In maintenance" value={number(inShop)} hint="Vehicles in shop" icon={<Wrench className="h-5 w-5" />} tone="warning" />
        <Kpi label="Fleet utilization" value={`${fleetUtil}%`} hint="On-trip vs active" icon={<TrendingUp className="h-5 w-5" />} tone="info" />
        <Kpi label="Drivers" value={number(totalDrivers)} hint={`${driversOnTrip} on trip`} icon={<Users className="h-5 w-5" />} />
        <Kpi label="Active trips" value={number(activeTrips)} hint="In progress now" icon={<RouteIcon className="h-5 w-5" />} tone="info" />
        <Kpi label="Fuel logged" value={number(data.fuel.length)} hint="Total entries" icon={<Fuel className="h-5 w-5" />} tone="accent" />
        <Kpi label="Monthly expenses" value={currency(monthlyExpenses)} hint="This month, all types" icon={<DollarSign className="h-5 w-5" />} tone="warning" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Monthly trips</CardTitle><CardDescription>Trip volume and completions (last 6 months)</CardDescription></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer>
              <AreaChart data={tripsByMonth}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--color-chart-1)" stopOpacity={0.5} /><stop offset="95%" stopColor="var(--color-chart-1)" stopOpacity={0} /></linearGradient>
                  <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--color-chart-3)" stopOpacity={0.5} /><stop offset="95%" stopColor="var(--color-chart-3)" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} />
                <Area type="monotone" dataKey="trips" stroke="var(--color-chart-1)" fill="url(#g1)" />
                <Area type="monotone" dataKey="completed" stroke="var(--color-chart-3)" fill="url(#g2)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Fuel cost analysis</CardTitle><CardDescription>Monthly fuel spend</CardDescription></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer>
              <BarChart data={fuelByMonth}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} formatter={(v: number) => currency(v)} />
                <Bar dataKey="cost" fill="var(--color-chart-2)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Maintenance cost</CardTitle><CardDescription>Monthly maintenance spend</CardDescription></CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer>
              <LineChart data={maintByMonth}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} formatter={(v: number) => currency(v)} />
                <Line type="monotone" dataKey="cost" stroke="var(--color-chart-4)" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Expense breakdown</CardTitle><CardDescription>By category</CardDescription></CardHeader>
          <CardContent className="h-72">
            {expenseBreakdown.length === 0 ? <p className="grid h-full place-items-center text-sm text-muted-foreground">No expenses yet</p> : (
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={expenseBreakdown} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={2}>
                    {expenseBreakdown.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} formatter={(v: number) => currency(v)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Fleet performance</CardTitle><CardDescription>Trips and total distance per vehicle</CardDescription></CardHeader>
          <CardContent className="h-72">
            {perf.length === 0 ? <p className="grid h-full place-items-center text-sm text-muted-foreground">Add vehicles to see performance</p> : (
              <ResponsiveContainer>
                <BarChart data={perf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" stroke="var(--color-muted-foreground)" fontSize={12} />
                  <YAxis stroke="var(--color-muted-foreground)" fontSize={12} />
                  <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="trips" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="distance" fill="var(--color-chart-2)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader><CardTitle>Recent trips</CardTitle></CardHeader>
        <CardContent>
          {recentTrips.length === 0 ? <p className="text-sm text-muted-foreground">No trips recorded yet.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs uppercase text-muted-foreground">
                  <tr><th className="p-2 text-left">Route</th><th className="p-2 text-left">Departure</th><th className="p-2 text-left">Distance</th><th className="p-2 text-left">Status</th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {recentTrips.map((t) => (
                    <tr key={t.id}>
                      <td className="p-2 font-medium">{t.source} → {t.destination}</td>
                      <td className="p-2 text-muted-foreground">{dateFmt(t.departure_date)}</td>
                      <td className="p-2">{number(Number(t.distance_km))} km</td>
                      <td className="p-2"><Badge variant="outline" className="capitalize">{t.status.replace("_", " ")}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
