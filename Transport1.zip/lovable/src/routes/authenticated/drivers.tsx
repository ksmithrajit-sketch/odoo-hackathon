import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/app-shell";
import { CrudTable, StatusBadge, DialogClose, type Column } from "@/components/crud-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { dateFmt } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/drivers")({
  head: () => ({ meta: [{ title: "Drivers — TransitOps" }] }),
  component: DriversPage,
});

type Driver = {
  id: string; full_name: string; license_number: string; license_expiry: string;
  phone: string | null; email: string | null; address: string | null;
  safety_score: number; status: "available" | "on_trip" | "inactive";
};

function DriverForm({ initial, onDone }: { initial?: Driver; onDone: () => void }) {
  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      full_name: String(fd.get("full_name")),
      license_number: String(fd.get("license_number")).toUpperCase(),
      license_expiry: String(fd.get("license_expiry")),
      phone: (fd.get("phone") || null) as string | null,
      email: (fd.get("email") || null) as string | null,
      address: (fd.get("address") || null) as string | null,
      safety_score: Number(fd.get("safety_score") || 80),
      status: String(fd.get("status")) as Driver["status"],
    };
    const { error } = initial
      ? await supabase.from("drivers").update(payload).eq("id", initial.id)
      : await supabase.from("drivers").insert(payload);
    if (error) return toast.error(error.message);
    toast.success(initial ? "Driver updated" : "Driver added");
    onDone();
  };
  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="sm:col-span-2"><Label>Full name</Label><Input name="full_name" required defaultValue={initial?.full_name} /></div>
        <div><Label>License #</Label><Input name="license_number" required defaultValue={initial?.license_number} /></div>
        <div><Label>License expiry</Label><Input name="license_expiry" type="date" required defaultValue={initial?.license_expiry} /></div>
        <div><Label>Phone</Label><Input name="phone" defaultValue={initial?.phone ?? ""} /></div>
        <div><Label>Email</Label><Input name="email" type="email" defaultValue={initial?.email ?? ""} /></div>
        <div className="sm:col-span-2"><Label>Address</Label><Input name="address" defaultValue={initial?.address ?? ""} /></div>
        <div><Label>Safety score (0-100)</Label><Input name="safety_score" type="number" min="0" max="100" defaultValue={initial?.safety_score ?? 80} /></div>
        <div><Label>Status</Label>
          <Select name="status" defaultValue={initial?.status ?? "available"}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{["available","on_trip","inactive"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <DialogClose onClose={onDone} />
    </form>
  );
}

function DriversPage() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const columns: Column<Driver>[] = [
    { key: "full_name", label: "Name", sortable: true, render: (r) => <span className="font-medium">{r.full_name}</span> },
    { key: "license_number", label: "License", render: (r) => <span className="font-mono">{r.license_number}</span> },
    { key: "license_expiry", label: "Expiry", render: (r) => {
      const exp = new Date(r.license_expiry);
      const expired = exp < new Date();
      return <span className={expired ? "text-destructive font-medium" : ""}>{dateFmt(r.license_expiry)}{expired && " (expired)"}</span>;
    } },
    { key: "phone", label: "Phone" },
    { key: "safety_score", label: "Safety", render: (r) => <Badge variant="outline">{r.safety_score}</Badge> },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];
  return (
    <>
      <PageHeader title="Drivers" description="Roster, licenses and safety scores." />
      <CrudTable<Driver>
        table="drivers"
        columns={columns}
        searchKeys={["full_name","license_number","email","phone"]}
        orderBy={{ column: "created_at" }}
        csvName="drivers"
        filterFn={(r) => statusFilter === "all" || r.status === statusFilter}
        filterBar={
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-9 w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {["available","on_trip","inactive"].map((s) => <SelectItem key={s} value={s} className="capitalize">{s.replace("_"," ")}</SelectItem>)}
            </SelectContent>
          </Select>
        }
        createForm={(done) => <DriverForm onDone={done} />}
        editForm={(row, done) => <DriverForm initial={row} onDone={done} />}
      />
    </>
  );
}
