import { useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Plus, Search, Trash2, Pencil, Loader2, ArrowUpDown, Download } from "lucide-react";
import { toast } from "sonner";
import { downloadCSV } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export interface Column<T> {
  key: keyof T | string;
  label: string;
  render?: (row: T) => ReactNode;
  sortable?: boolean;
  className?: string;
}

interface CrudTableProps<T extends { id: string }> {
  table: string;
  columns: Column<T>[];
  searchKeys: (keyof T)[];
  orderBy?: { column: string; ascending?: boolean };
  createForm: (onDone: () => void, initial?: T) => ReactNode;
  filterBar?: ReactNode;
  filterFn?: (row: T) => boolean;
  editForm?: (row: T, onDone: () => void) => ReactNode;
  csvName?: string;
  emptyMessage?: string;
  pageSize?: number;
}

export function CrudTable<T extends { id: string; [k: string]: any }>({
  table, columns, searchKeys, orderBy, createForm, editForm, filterBar, filterFn, csvName, emptyMessage = "No records yet", pageSize = 10,
}: CrudTableProps<T>) {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [sortKey, setSortKey] = useState<string | null>(orderBy?.column ?? null);
  const [sortAsc, setSortAsc] = useState(orderBy?.ascending ?? false);
  const [openCreate, setOpenCreate] = useState(false);
  const [editRow, setEditRow] = useState<T | null>(null);

  const { data, isLoading } = useQuery<T[]>({
    queryKey: [table],
    queryFn: async () => {
      const client = supabase as any;
      const q = client.from(table).select("*");
      if (orderBy) q.order(orderBy.column, { ascending: orderBy.ascending ?? false });
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as T[];
    },
  });

  const filtered = (data ?? [])
    .filter((r) => (filterFn ? filterFn(r) : true))
    .filter((r) => {
      if (!search) return true;
      const q = search.toLowerCase();
      return searchKeys.some((k) => String(r[k as string] ?? "").toLowerCase().includes(q));
    });

  const sorted = sortKey ? [...filtered].sort((a, b) => {
    const av = a[sortKey]; const bv = b[sortKey];
    if (av == null) return 1; if (bv == null) return -1;
    return sortAsc ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
  }) : filtered;

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const pageRows = sorted.slice((page - 1) * pageSize, page * pageSize);

  const del = async (id: string) => {
    const { error } = await (supabase as any).from(table).delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Deleted");
    qc.invalidateQueries({ queryKey: [table] });
  };

  const invalidate = () => qc.invalidateQueries({ queryKey: [table] });

  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 pb-4 sm:flex sm:flex-wrap sm:justify-between">
          <div className="relative min-w-0 flex-1 sm:max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="pl-9" />
          </div>
          <div className="flex shrink-0 items-center gap-2">
            {filterBar}
            {csvName && (
              <Button variant="outline" size="sm" onClick={() => downloadCSV(csvName + ".csv", sorted as any)}><Download className="mr-1.5 h-4 w-4" />CSV</Button>
            )}
            <Dialog open={openCreate} onOpenChange={setOpenCreate}>
              <DialogTrigger asChild><Button size="sm"><Plus className="mr-1.5 h-4 w-4" />New</Button></DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>New record</DialogTitle><DialogDescription>Add a new entry.</DialogDescription></DialogHeader>
                {createForm(() => { setOpenCreate(false); invalidate(); })}
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="overflow-x-auto rounded-md border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
              <tr>
                {columns.map((c) => (
                  <th key={String(c.key)} className={`p-3 text-left font-medium ${c.className ?? ""}`}>
                    {c.sortable ? (
                      <button className="inline-flex items-center gap-1 hover:text-foreground" onClick={() => { setSortAsc(sortKey === c.key ? !sortAsc : true); setSortKey(String(c.key)); }}>
                        {c.label}<ArrowUpDown className="h-3 w-3" />
                      </button>
                    ) : c.label}
                  </th>
                ))}
                <th className="w-24 p-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading && <tr><td colSpan={columns.length + 1} className="p-8 text-center"><Loader2 className="mx-auto h-5 w-5 animate-spin text-muted-foreground" /></td></tr>}
              {!isLoading && pageRows.length === 0 && <tr><td colSpan={columns.length + 1} className="p-8 text-center text-sm text-muted-foreground">{emptyMessage}</td></tr>}
              {pageRows.map((row) => (
                <tr key={row.id} className="transition-colors hover:bg-muted/40">
                  {columns.map((c) => (
                    <td key={String(c.key)} className={`p-3 ${c.className ?? ""}`}>
                      {c.render ? c.render(row) : String(row[c.key as string] ?? "—")}
                    </td>
                  ))}
                  <td className="p-3">
                    <div className="flex items-center justify-end gap-1">
                      {editForm && (
                        <Dialog open={editRow?.id === row.id} onOpenChange={(o) => setEditRow(o ? row : null)}>
                          <DialogTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button></DialogTrigger>
                          <DialogContent className="max-w-lg">
                            <DialogHeader><DialogTitle>Edit record</DialogTitle></DialogHeader>
                            {editRow?.id === row.id && editForm(editRow, () => { setEditRow(null); invalidate(); })}
                          </DialogContent>
                        </Dialog>
                      )}
                      <AlertDialog>
                        <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader><AlertDialogTitle>Delete this record?</AlertDialogTitle><AlertDialogDescription>This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => del(row.id)}>Delete</AlertDialogAction></AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between pt-3 text-sm text-muted-foreground">
          <span>Showing {pageRows.length ? (page - 1) * pageSize + 1 : 0}–{(page - 1) * pageSize + pageRows.length} of {sorted.length}</span>
          <div className="flex gap-1">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>Prev</Button>
            <span className="grid h-8 min-w-8 place-items-center rounded-md border border-border px-2 text-xs">{page} / {totalPages}</span>
            <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>Next</Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function statusVariant(s: string): "default" | "secondary" | "destructive" | "outline" {
  if (["available", "completed"].includes(s)) return "default";
  if (["on_trip", "in_progress", "scheduled"].includes(s)) return "secondary";
  if (["in_shop", "pending", "inactive"].includes(s)) return "outline";
  return "outline";
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    available: "bg-success/15 text-success border-success/30",
    on_trip: "bg-info/15 text-info border-info/30",
    in_progress: "bg-info/15 text-info border-info/30",
    scheduled: "bg-muted text-muted-foreground border-border",
    in_shop: "bg-warning/25 text-warning-foreground border-warning/40",
    pending: "bg-warning/25 text-warning-foreground border-warning/40",
    completed: "bg-success/15 text-success border-success/30",
    inactive: "bg-muted text-muted-foreground border-border",
    retired: "bg-destructive/10 text-destructive border-destructive/30",
    cancelled: "bg-destructive/10 text-destructive border-destructive/30",
  };
  return <Badge variant="outline" className={`capitalize ${map[status] ?? ""}`}>{status.replace("_", " ")}</Badge>;
}

export const DialogClose = ({ onClose, label = "Cancel" }: { onClose: () => void; label?: string }) => (
  <DialogFooter>
    <Button type="button" variant="outline" onClick={onClose}>{label}</Button>
    <Button type="submit">Save</Button>
  </DialogFooter>
);
